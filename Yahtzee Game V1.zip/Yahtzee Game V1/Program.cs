﻿using System;
using System.Collections.Generic;
using System.Linq;

class Yahtzee
{
    static Random random = new Random();

    static void Main(string[] args)
    {
        try
        {
            Console.WriteLine("Welcome to Yahtzee!");

            int numberOfPlayers = GetNumberOfPlayers();
            List<Player> players = InitializePlayers(numberOfPlayers);
            string[] categories = {
                "Ones", "Twos", "Threes", "Fours", "Fives", "Sixes",
                "Three of a Kind", "Four of a Kind", "Full House",
                "Small Straight", "Large Straight", "Yahtzee", "Chance"
            };

            int rounds = categories.Length;

            for (int round = 1; round <= rounds; round++)
            {
                Console.WriteLine($"\n--- Round {round} ---");
                foreach (var player in players)
                {
                    Console.WriteLine($"\n{player.Name}'s turn:");
                    int[] dice = new int[5];
                    PlayTurn(dice);
                    Console.WriteLine("Final dice:");
                    DisplayDice(dice);

                    Console.WriteLine("\nAvailable categories:");
                    DisplayAvailableCategories(player, categories);

                    int categoryChoice = GetCategoryChoice(player, categories);
                    int score = CalculateScore(dice, categories[categoryChoice]);
                    player.Scores[categoryChoice] = score;
                    Console.WriteLine($"{player.Name} scored {score} points in {categories[categoryChoice]}.\n");
                }
            }

            DisplayFinalScores(players, categories);
            AnnounceWinner(players);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"\nAn unexpected error occurred: {ex.Message}");
        }
        finally
        {
            Console.WriteLine("\nPress any key to exit.");
            Console.ReadKey();
        }
    }

    static int GetNumberOfPlayers()
    {
        while (true)
        {
            Console.Write("Enter the number of players (1-4): ");
            string input = Console.ReadLine()?.Trim();
            if (int.TryParse(input, out int numPlayers) && numPlayers >= 1 && numPlayers <= 4)
            {
                return numPlayers;
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a number between 1 and 4.");
            }
        }
    }

    static List<Player> InitializePlayers(int numberOfPlayers)
    {
        List<Player> players = new List<Player>();
        for (int i = 1; i <= numberOfPlayers; i++)
        {
            Console.Write($"Enter name for Player {i}: ");
            string name = Console.ReadLine()?.Trim();
            if (string.IsNullOrEmpty(name))
            {
                name = $"Player {i}";
            }
            players.Add(new Player(name));
        }
        return players;
    }

    static void PlayTurn(int[] dice)
    {
        RollAllDice(dice);
        int rollsLeft = 2;
        while (rollsLeft > 0)
        {
            Console.WriteLine("\nYour current dice:");
            DisplayDice(dice);

            Console.Write("Do you want to re-roll any dice? (y/n): ");
            string input = Console.ReadLine()?.Trim().ToLower();

            if (input == "y")
            {
                List<int> diceToReroll = GetDiceToReroll();
                if (diceToReroll.Count > 0)
                {
                    RerollDice(dice, diceToReroll);
                    rollsLeft--;
                }
                else
                {
                    Console.WriteLine("No dice selected for re-roll.");
                    break;
                }
            }
            else if (input == "n")
            {
                break;
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter 'y' or 'n'.");
            }
        }
    }

    static int GetCategoryChoice(Player player, string[] categories)
    {
        while (true)
        {
            Console.Write("Select a category by number: ");
            string input = Console.ReadLine()?.Trim();
            if (int.TryParse(input, out int choice))
            {
                choice -= 1; // Adjust for zero-based index
                if (choice >= 0 && choice < categories.Length)
                {
                    if (player.Scores[choice] == null)
                    {
                        return choice;
                    }
                    else
                    {
                        Console.WriteLine("Category already used. Please select a different category.");
                    }
                }
                else
                {
                    Console.WriteLine($"Invalid choice. Please select a number between 1 and {categories.Length}.");
                }
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a valid category number.");
            }
        }
    }

    static void DisplayAvailableCategories(Player player, string[] categories)
    {
        for (int i = 0; i < categories.Length; i++)
        {
            if (player.Scores[i] == null)
            {
                Console.WriteLine($"{i + 1}. {categories[i]}");
            }
        }
    }

    static void DisplayFinalScores(List<Player> players, string[] categories)
    {
        Console.WriteLine("\n--- Final Scores ---");
        foreach (var player in players)
        {
            int totalScore = player.Scores.Where(s => s.HasValue).Sum(s => s.Value);
            Console.WriteLine($"\n{player.Name}'s Scorecard:");
            for (int i = 0; i < categories.Length; i++)
            {
                string score = player.Scores[i]?.ToString() ?? "-";
                Console.WriteLine($"{categories[i]}: {score}");
            }
            Console.WriteLine($"Total Score: {totalScore}");
        }
    }

    static void AnnounceWinner(List<Player> players)
    {
        var winner = players.OrderByDescending(p => p.Scores.Where(s => s.HasValue).Sum(s => s.Value)).First();
        Console.WriteLine($"\nCongratulations {winner.Name}! You have the highest score.");
    }

    static int CalculateScore(int[] dice, string category)
    {
        int score = 0;
        int[] counts = new int[6];
        foreach (int die in dice)
        {
            counts[die - 1]++;
        }

        switch (category)
        {
            case "Ones":
            case "Twos":
            case "Threes":
            case "Fours":
            case "Fives":
            case "Sixes":
                int dieValue = Array.IndexOf(new string[] { "Ones", "Twos", "Threes", "Fours", "Fives", "Sixes" }, category) + 1;
                score = counts[dieValue - 1] * dieValue;
                break;
            case "Three of a Kind":
                if (counts.Any(c => c >= 3))
                {
                    score = dice.Sum();
                }
                break;
            case "Four of a Kind":
                if (counts.Any(c => c >= 4))
                {
                    score = dice.Sum();
                }
                break;
            case "Full House":
                if (counts.Contains(3) && counts.Contains(2))
                {
                    score = 25;
                }
                break;
            case "Small Straight":
                if (IsSmallStraight(dice))
                {
                    score = 30;
                }
                break;
            case "Large Straight":
                if (IsLargeStraight(dice))
                {
                    score = 40;
                }
                break;
            case "Yahtzee":
                if (counts.Any(c => c == 5))
                {
                    score = 50;
                }
                break;
            case "Chance":
                score = dice.Sum();
                break;
        }

        return score;
    }

    static bool IsSmallStraight(int[] dice)
    {
        var uniqueDice = dice.Distinct().OrderBy(d => d).ToArray();
        int[][] straights = {
            new int[] {1,2,3,4},
            new int[] {2,3,4,5},
            new int[] {3,4,5,6}
        };

        foreach (var straight in straights)
        {
            if (straight.All(s => uniqueDice.Contains(s)))
            {
                return true;
            }
        }
        return false;
    }

    static bool IsLargeStraight(int[] dice)
    {
        var uniqueDice = dice.Distinct().OrderBy(d => d).ToArray();
        int[] straight1 = { 1, 2, 3, 4, 5 };
        int[] straight2 = { 2, 3, 4, 5, 6 };

        return uniqueDice.SequenceEqual(straight1) || uniqueDice.SequenceEqual(straight2);
    }

    static void RollAllDice(int[] dice)
    {
        for (int i = 0; i < dice.Length; i++)
        {
            dice[i] = RollDice();
        }
    }

    static void RerollDice(int[] dice, List<int> diceToReroll)
    {
        foreach (int index in diceToReroll)
        {
            if (index >= 0 && index < dice.Length)
            {
                dice[index] = RollDice();
            }
        }
    }

    static List<int> GetDiceToReroll()
    {
        while (true)
        {
            Console.Write("Enter the numbers of the dice you want to re-roll (e.g., 1 3 5), or 'none' to keep all dice: ");
            string input = Console.ReadLine()?.Trim().ToLower();

            if (string.IsNullOrEmpty(input) || input == "none")
            {
                return new List<int>(); // No dice to re-roll
            }

            string[] tokens = input.Split(new[] { ' ', ',', ';' }, StringSplitOptions.RemoveEmptyEntries);
            List<int> diceToReroll = new List<int>();
            bool validInput = true;

            foreach (string token in tokens)
            {
                if (int.TryParse(token, out int dieNumber))
                {
                    if (dieNumber >= 1 && dieNumber <= 5)
                    {
                        if (!diceToReroll.Contains(dieNumber - 1))
                        {
                            diceToReroll.Add(dieNumber - 1); // Convert to zero-based index
                        }
                        else
                        {
                            Console.WriteLine($"You have already selected dice {dieNumber} for re-roll.");
                            validInput = false;
                            break;
                        }
                    }
                    else
                    {
                        Console.WriteLine($"Invalid dice number: {dieNumber}. Please enter numbers between 1 and 5.");
                        validInput = false;
                        break;
                    }
                }
                else
                {
                    Console.WriteLine($"Invalid input: '{token}'. Please enter valid dice numbers.");
                    validInput = false;
                    break;
                }
            }

            if (validInput)
            {
                return diceToReroll;
            }
            else
            {
                Console.WriteLine("Please try again.");
            }
        }
    }

    static void DisplayDice(int[] dice)
    {
        for (int i = 0; i < dice.Length; i++)
        {
            Console.WriteLine($"Dice {i + 1}: {dice[i]}");
        }
    }

    static int RollDice()
    {
        return random.Next(1, 7);
    }
}

class Player
{
    public string Name { get; set; }
    public int?[] Scores { get; set; }

    public Player(string name)
    {
        Name = name;
        Scores = new int?[13]; // 13 categories in Yahtzee
    }
}
